def main():
    print('Hello, Dzhamankulov Amantur')


if __name__ == '__main__':
    main()
